brew install homebrew/versions/glfw3 glew freetype pkg-config
